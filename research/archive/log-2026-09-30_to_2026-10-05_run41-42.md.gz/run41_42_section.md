## 2026-09-30 — Run 41 (same-day deferred no-op)

**Housekeeping first.** This container's clone again had local `main`
pinned one commit behind (`67b2af0`) with `origin/main` already at Run 40's
`820a0aa`, same stale-pointer pattern as Run 40's own housekeeping note (a
fresh container clone predates the previous session's push). Fast-forwarded
local `main` to `origin/main` (`820a0aa`) via `git checkout main && git
merge --ff-only origin/main` — clean fast-forward, no divergent commits, no
work at risk. Re-verified the Run 37 malware incident remains remediated:
no `.vscode/` directory, `public/fonts/*` all legitimate FontAwesome
filenames (no `-400`/`-500` swapped fake font), no stray `eval(` in
`public/`. Nothing new to flag.

**Question.** This scheduled fire lands on 2026-09-30 — the same calendar
date as Run 40's commit (`820a0aa`, 2026-09-30 02:11:47 UTC). Run 40 itself
set the next actionable date for the standing DCA self-correction protocol
at "2026-10-02 or later" (2+ full days past its own 2026-09-30 anchor) and
explicitly said a same-day or next-day re-fire should defer as a no-op,
exactly as Run 39 did for Run 38. That bar is not yet met today, so this
run defers rather than re-running the self-correction check on <24h of new
data (which would just reproduce Run 40's numbers with noise-level
rounding, adding no information).

**Fresh-idea check.** Re-scanned DISTILLED LEARNINGS for anything
mechanically distinct from the closed list (8 strategy families, 6
signal-source categories, 3 confirmation gates + 1 stacked combo, 2
cross-symbol constructions, sizing, exit mechanism, cost level, symbol
universe, TF range, historical era, DCA parameter + trend-gate
conditioning) that would be worth testing before the next scheduled
self-correction date. None identified — the only structurally out-of-reach
items remain short-selling (architecture change, out of scope per the
task's own auto-improve boundaries) and geo-blocked futures/funding data.
No new construction proposed this run.

**Verification.** `cd backend && .venv/bin/python -m pytest` — 95 passed, 0
failed, matching Run 37/38/40's count exactly, no drift. No code, params,
or shipped defaults touched.

**Decision: no-op deferral, nothing to log.** No backtest configs run, no
`decisions.jsonl` entry added (would just be a duplicate-window rerun of
Run 40 with no new signal), no code changes, no candidate.

**Going forward:** next actionable date for the DCA self-correction check
remains 2026-10-02 or later, per Run 40. Unchanged from Run 40's guidance.

**Files:** none changed in `backend/` or `research/experiments/`.
`decisions.jsonl` unchanged (158 active). `rotate_archive.py` not run (no
new entries to rotate). `RESEARCH_LOG.md` run-section count is now 9
(33-41); file size (~53KB) is further over the ~40KB soft guideline with 9
active sections — still under the ~15-run archival floor, but the next run
that does real work should fold Run 33-36 (the oldest, already-closed
strategy-family sections whose conclusions are fully captured in DISTILLED
LEARNINGS) into a new `research/archive/log-2026-08-28_to_2026-09-XX.md.gz`
to bring the active file back under budget.

---

## 2026-10-05 — Run 42 (self-correction, on schedule; memory hygiene)

**Housekeeping first.** Fresh container clone, `HEAD` detached at
`refs/heads/main` pointing at `f697c2b` (Run 41's commit), already matching
`origin/main` — no stale-pointer fast-forward needed this time, just
`git checkout main`. Re-verified the Run 37 malware incident remains
remediated: no `.vscode/` directory, `public/fonts/*` all legitimate
FontAwesome filenames (`fa-solid-900`, `fa-brands-400`, `fa-regular-400` —
no `-400`/`-500` swapped fake font), no stray `eval(` anywhere under
`public/`. Nothing new to flag.

**Question.** Run 40 set the next actionable date for the standing DCA
self-correction protocol at "2026-10-02 or later" (2+ full days past its
2026-09-30 anchor). Run 41 fired the same day as Run 40 and correctly
deferred. No run fired between Run 41 (2026-09-30) and today (2026-10-05) —
a 5-day gap, the bar is well met, so this run performs the genuine re-check.
No concretely-scoped strategy/signal/gate axis has reopened since Run 41;
every one of them (8 strategy families, 6 signal-source categories, gates,
cross-symbol constructions, sizing, exit mechanism, cost level, symbol
universe, TF range, historical era, DCA parameter + trend-gate conditioning)
remains closed with zero surviving candidates, and the only structurally
out-of-reach items (short-selling, geo-blocked futures data) are unchanged.

**Method.** Same methodology as Run 4/14/27/32/35/36/38/40 (capital-
normalized average ROI across the 8-symbol universe, dip_enabled=True
(shipped, `dip_threshold_pct=5.0`, `dip_multiplier=1.5`) vs dip_enabled=False
(control), 1h entry timeframe, 7.5bps fees/4bps slippage). All 3
non-overlapping windows shifted forward by exactly 5 days vs Run 40 (same
window lengths — older/train 90d, test 60d): older
2026-02-07..2026-05-08, train 2026-05-08..2026-08-06, test
2026-08-06..2026-10-05 (anchor = today's close).

**Result — same regime-dependent signature, no reversal.**

| window | OFF avg ROI% | ON-OFF delta (pp) | symbols beating OFF | dip-buys fired |
|---|---|---|---|---|
| older (mild uptrend) | +5.8615 | **+0.0466** | 6/8 | 21 |
| train (real decline) | -3.7354 | **+0.0144** | 5/8 | 28 |
| test (strong rally) | +19.9811 | **-0.1515** | 0/8 | 13 |

Identical sign pattern to every prior check since Run 4: mild positive when
the window contains a real decline or chop, a small unanimous drag when the
window is a sustained rally (only 13 dip-buys fired across all 8 symbols in
60 days of a +20% rally). All 3 deltas are inside the established <=0.40pp
noise envelope (this run's max magnitude is 0.1515pp, between Run 38's
0.1182pp and Run 40's 0.1651pp — no trend of growing magnitude). **No
reversal, no quiet degradation of the shipped default — no git revert
warranted.**

**$ impact:** test-window delta (the decision-relevant window) is -$0.1515
on $100 invested notional / -$1.515 on $1000 — economically trivial, as
established since Run 4.

**Decision: noise — shipped default (`dip_threshold_pct=5.0`,
`dip_multiplier=1.5`) reconfirmed, no code change.**

**No code change** — pure self-correction re-check; no auto-improve
threshold was met, no revert was warranted. Full backend test suite re-run:
`cd backend && .venv/bin/python -m pytest` — 95 passed, 0 failed, matching
Run 37/38/39/40/41's count exactly, no drift.

**Memory hygiene this run:** `RESEARCH_LOG.md` had grown to ~53KB (over the
~40KB soft guideline) across 9 active run-sections (33-41), exactly as Run
41 flagged. Archived Run 33-36 (the oldest, already-closed strategy-family
sections — BB-squeeze breakout, DCA multiplier/threshold isolation, trend-
gate conditioning; all conclusions already folded into DISTILLED LEARNINGS)
to `research/archive/log-2026-08-28_to_2026-08-30_run33-36.md.gz` (gzip, no
conclusions dropped). Active run-section count is now 6 (37-42); file size
reduced to ~30KB, back under budget. `rotate_archive.py` run:
`decisions.jsonl` at 159 entries, still under the 250 rotation threshold, no
`.jsonl` rotation this cycle.

**Going forward:** next self-correction check due once 2+ full days of new
data have accumulated past this run's 2026-10-05 anchor, i.e. 2026-10-07 or
later; a same-day or next-day re-fire should defer as a no-op exactly as Run
39/41 did. A fresh strategy/signal idea would need to be mechanically
distinct from every closed item in DISTILLED LEARNINGS to be worth testing
before then — none identified this run.

**Files:** `research/experiments/dca_self_correction_run42.py` (new, copied
from Run 40's script with windows rolled forward +5 days).
`research/experiments/dca_self_correction_run42_output.json` (new, raw
per-symbol output). 1 entry appended to `research/decisions.jsonl` (159
active, no rotation triggered). `research/archive/log-2026-08-28_to_2026-08-30_run33-36.md.gz`
(new archive, Run 33-36 narrative). Active `RESEARCH_LOG.md` run-section
count is now 6 (37-42), file size ~30KB, back under the ~40KB guideline.

---

